public class Coche {

    private int puertas=2;

    public void agregarPuertas(int cantPuertas){
        puertas = puertas+cantPuertas;
    }

    public int getPuertas(){
        return puertas;
    }
}
